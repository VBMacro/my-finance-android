# My Finance Android APK — V1.0

Android wrapper for the stable My Finance PWA V1.2.5.

## Build from phone using GitHub

1. Create/use the GitHub repository `my-finance`.
2. Upload the contents of this project to the repository root.
3. Open **Actions** → **Build My Finance APK**.
4. Tap **Run workflow** (or push to `main`).
5. Open the completed workflow run.
6. Under **Artifacts**, download `MyFinance-APK`.
7. Extract the artifact and install `MyFinance.apk` on Android.

The APK contains the V1.2.5 app locally, so it does not depend on GitHub Pages to run.

## Important

- Existing PWA data is not automatically transferred into the APK.
- Before switching, use **Export Backup** in the PWA and keep `my-finance-backup.json`.
- After installing the APK, use **Import Backup** to restore your data.
- The APK uses its own app storage, so the PWA and APK have separate local data.
